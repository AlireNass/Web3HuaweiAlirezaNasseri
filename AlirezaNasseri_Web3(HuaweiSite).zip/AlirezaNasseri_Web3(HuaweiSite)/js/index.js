//activate Animations
AOS.init();
$(document).ready(function () {
    //scroll up after reload
    $(this).scrollTop(0);
    // the x close button
    $(".clos").click(function () {
        $("#myModal").hide(0);
    });

    //the Corporate button top of page
    $("#slide-corp").click(function () {
        $("#slide-corp").toggleClass("makewhite");
        $("#slide-world").removeClass("makewhite");
        $("#slide-corp span, #slide-corp i").toggleClass("ch1");
        $("#slide-world span, #slide-world i").removeClass("ch1");
        $(".icon2").toggleClass("bi-chevron-down bi-chevron-up");
        $(".icon3").addClass("bi-chevron-down");
        $(".icon3").removeClass("bi-chevron-up");
        $("#corp").slideToggle("slow");
        $("#world").slideUp();
        $("#partners").hide();
        $("#modality1").hide();
        $("#modality2").hide();
        $("#modality3").hide();
        $("#modality4").hide();
        $("#modality5").hide();
        $("#consumer-pro-menu").hide();
        $("#Business-prod").hide();
        $("#support").hide();
        $("#abouthw").hide();
        $("#about").removeClass("linked3");
        $("#buss").removeClass("linked4");
        $("#supp").removeClass("linked2");
        $("#part").removeClass("linked");
        $("#cons").removeClass("linked");
    });
    //the WorldWide button top of page
    $("#slide-world").click(function () {
        $("#slide-world").toggleClass("makewhite");
        $("#slide-corp").removeClass("makewhite");
        $("#slide-world span, #slide-world i").toggleClass("ch1");
        $("#slide-corp span, #slide-corp i").removeClass("ch1");
        $(".icon3").toggleClass("bi-chevron-down bi-chevron-up");
        $(".icon2").addClass("bi-chevron-down")
        $(".icon2").removeClass("bi-chevron-up")
        $("#world").slideToggle("slow");
        $("#corp").slideUp();
        $("#modality1").hide();
        $("#modality2").hide();
        $("#modality3").hide();
        $("#modality4").hide();
        $("#modality5").hide();
        $("#partners").hide();
        $("#consumer-pro-menu").hide();
        $("#Business-prod").hide();
        $("#support").hide();
        $("#abouthw").hide();
        $("#about").removeClass("linked3");
        $("#buss").removeClass("linked4");
        $("#supp").removeClass("linked2");
        $("#part").removeClass("linked");
        $("#cons").removeClass("linked");
    });
    //nav header called "Consumer Products"
    $("#cons").click(function () {
        $("#consumer-pro-menu").slideToggle();
        $("#cons").toggleClass("linked");
        $("#buss").removeClass("linked4");
        $("#supp").removeClass("linked2");
        $("#part").removeClass("linked");
        $("#about").removeClass("linked3");
        $("#modality1").toggle();
        $("#modality2").hide();
        $("#modality3").hide();
        $("#modality4").hide();
        $("#modality5").hide();
        $("#Business-prod").hide();
        $("#support").hide();
        $("#partners").hide();
        $("#abouthw").hide();
    });
    //nav header called "Business Products"
    $("#buss").click(function () {
        $("#Business-prod").slideToggle();
        $("#buss").toggleClass("linked4");
        $("#cons").removeClass("linked");
        $("#supp").removeClass("linked2");
        $("#part").removeClass("linked");
        $("#about").removeClass("linked3");
        $("#modality2").toggle();
        $("#modality1").hide();
        $("#modality3").hide();
        $("#modality4").hide();
        $("#modality5").hide();
        $("#consumer-pro-menu").hide();
        $("#support").hide();
        $("#partners").hide();
        $("#abouthw").hide();
    });
    //nav header called "Support"
    $("#supp").click(function () {
        $("#support").slideToggle();
        $("#supp").toggleClass("linked2");
        $("#buss").removeClass("linked4");
        $("#cons").removeClass("linked");
        $("#part").removeClass("linked");
        $("#about").removeClass("linked3");
        $("#modality3").toggle();
        $("#modality1").hide();
        $("#modality2").hide();
        $("#modality4").hide();
        $("#modality5").hide();
        $("#consumer-pro-menu").hide();
        $("#Business-prod").hide();
        $("#partners").hide();
        $("#abouthw").hide();
    });
    //nav header called "Partners & Developers"
    $("#part").click(function () {
        $("#partners").slideToggle();
        $("#part").toggleClass("linked");
        $("#buss").removeClass("linked4");
        $("#supp").removeClass("linked2");
        $("#cons").removeClass("linked");
        $("#about").removeClass("linked3");
        $("#modality4").toggle();
        $("#modality1").hide();
        $("#modality2").hide();
        $("#modality3").hide();
        $("#modality5").hide();
        $("#consumer-pro-menu").hide();
        $("#Business-prod").hide();
        $("#support").hide();
        $("#abouthw").hide();
    });
    //nav header called "About Huawei"
    $("#about").click(function () {
        $("#abouthw").slideToggle();
        $("#about").toggleClass("linked3");
        $("#buss").removeClass("linked4");
        $("#supp").removeClass("linked2");
        $("#part").removeClass("linked");
        $("#cons").removeClass("linked");
        $("#modality5").toggle();
        $("#modality1").hide();
        $("#modality2").hide();
        $("#modality3").hide();
        $("#modality4").hide();
        $("#consumer-pro-menu").hide();
        $("#Business-prod").hide();
        $("#support").hide();
        $("#partners").hide();
    });
    //Close x button for nav header
    $(".closer2").click(function () {
        $("#partners").hide();
        $("#consumer-pro-menu").hide();
        $("#modality1").hide();
        $("#modality2").hide();
        $("#modality3").hide();
        $("#modality4").hide();
        $("#modality5").hide();
        $("#Business-prod").hide();
        $("#support").hide();
        $("#abouthw").hide();
        $("#about").removeClass("linked3");
        $("#buss").removeClass("linked4");
        $("#supp").removeClass("linked2");
        $("#part").removeClass("linked");
        $("#cons").removeClass("linked");
    });
    //Close nav header's modal after double clicking screen
    $("body").dblclick(function () {
        $("#partners").hide();
        $("#consumer-pro-menu").hide();
        $("#Business-prod").hide();
        $("#support").hide();
        $("#abouthw").hide();
        $("#about").removeClass("linked3");
        $("#buss").removeClass("linked4");
        $("#supp").removeClass("linked2");
        $("#part").removeClass("linked");
        $("#cons").removeClass("linked");


    });
    //Close nav header's modal using escape(Esc) button
    $("body").keydown(function (e) {
        if (e.key == "Escape") {
            $("#partners").hide();
            $("#consumer-pro-menu").hide();
            $("#Business-prod").hide();
            $("#support").hide();
            $("#abouthw").hide();
            $("#about").removeClass("linked3");
            $("#buss").removeClass("linked4");
            $("#supp").removeClass("linked2");
            $("#part").removeClass("linked");
            $("#cons").removeClass("linked");
        }
    });
    //sticky icon(headsets) on right side of page, opening a modal
    $(".sticky-icon").click(function () {
        $("#myModal").show();
    });
    //sticky icon(go up) on right side of page, scrolling up the page to the top
    $(".sticky-icon2").click(function () {
        $(document).scrollTop(0);
    });
    //disables modal clicking anywhere on screen
    $("#myModal").click(function (e) {
        if (e.target != $(".mod-content")) {
            $("#myModal").hide();
        }
    });
    $(".line-container").click(function () {
        $(this).toggleClass("change");
        $(".small-menu").slideToggle();
        $("body").toggleClass("hidescroll");
        $(".sticky-icon").toggle();
    })


    //activate window's scroll function
    window.onscroll = function () { scrollFunction() };
    //sticky icon(go up) only appears when the User Scrolled down for 100px
    function scrollFunction() {
        if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
            $(".sticky-icon2").show(30);
        } else {
            $(".sticky-icon2").hide(0);
        }
    };
    //carousel options
    $('.owl-carousel').owlCarousel({
        loop: true,
        navigation: false,
        navText: [" ", " "],
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })

});
